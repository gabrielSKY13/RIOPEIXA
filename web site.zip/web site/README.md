![](print.gif)

> [!TIP]
> Utilize o comando `python3 manage.py createsuperuser` para criar um usuário *super admin*

- Instalar dependencias com o comando:
```bash
python -m pip install -r requirements.txt
```
- Iniciar aplicacao com:
```bash
python3 manage.py migrate
python3 manage.py runserver 127.0.0.1:8001
```