from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods
from django.contrib.auth import login as django_login, logout as django_logout
from django.contrib.auth.hashers import make_password, check_password
from .models import User, Address
import requests

def index(request):
    return render(request, "home.html")

def signup(request):
    return render(request, "signup.html")

def error(request):
    return render(request, "error.html")

def success(request):
    return render(request, "success.html")

@require_http_methods(["POST"])
def signup_create(request):
    name = request.POST.get('name')
    cpf = request.POST.get('cpf')
    email = request.POST.get('email')
    password = request.POST.get('password')
    cep = request.POST.get('cep')
    city = request.POST.get('city')
    street = request.POST.get('street')
    district = request.POST.get('district')
    
    if User.objects.filter(email=email).exists() or User.objects.filter(cpf=cpf).exists():
        return render(request, 'signup.html', { 'error_message': 'user already exists' })
    
    address = Address.objects.create(
        cep=cep,
        city=city,
        street=street,
        district=district
    )
    
    address.save()
    
    user = User.objects.create(
        name=name,
        cpf=cpf,
        email=email,
        password=make_password(password),
        address=address
    )

    user.save()

    django_login(request, user)
    return redirect('index')

def login(request):
    return render(request, "login.html")

@require_http_methods(["POST"])
def login_create(request):
    cpf = request.POST.get('cpf')
    password = request.POST.get('password')
    
    try:
        user = User.objects.get(cpf=cpf)
        if check_password(password, user.password):
            django_login(request, user)
            return redirect('index')
        else:
            return render(request, 'login.html', { 'error_message': 'user password incorrect' })
    except User.DoesNotExist:
        return render(request, 'login.html', { 'error_message': 'user not found' })

def contact(request):
    if not request.user.is_authenticated:
        return redirect('login')

    return render(request, "contact.html")

@require_http_methods(["POST"])
def contact_create(request):
    if not request.user.is_authenticated:
        return redirect('login')

    title = request.POST.get('title')
    description = request.POST.get('description')

    response = requests.post("http://127.0.0.1:8000/contacts", json={
        "title": title,
        "description": description
    })
    
    if response.status_code != 201:
        return redirect('error')
    
    return redirect('success')

def logout(request):
    django_logout(request)
    return redirect('login')