from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("signup", views.signup, name="signup"),
    path("signup/create", views.signup_create, name="signup_create"),
    path("login", views.login, name="login"),
    path("login/create", views.login_create, name="login_create"),
    path("contact", views.contact, name="contact"),
    path("contact/create", views.contact_create, name="contact_create"),
    path("logout", views.logout, name="logout"),
    path("error", views.error, name="error"),
    path("success", views.success, name="success")
]