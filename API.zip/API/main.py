from fastapi import FastAPI, Request, HTTPException, Body
from fastapi.responses import JSONResponse, Response
from typing import Optional
import sqlite3
import json

db_path = "db.sqlite3"

app = FastAPI()    

def get_contact(contact_id: Optional[int] = None):
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='contact';")
    result = cursor.fetchone()
    if not result:
        return None

    if contact_id:
        cursor.execute("SELECT * FROM contact WHERE id = ?", (contact_id,))
        columns = [description[0] for description in cursor.description]
        row = cursor.fetchone()
        if not row:
            return None
        result = dict(zip(columns, row))
    else:
        cursor.execute("SELECT * FROM contact;")
        columns = [description[0] for description in cursor.description]
        rows = cursor.fetchall()
        result = [dict(zip(columns, row)) for row in rows]

    # Converter para JSON
    json.dumps(result, indent=4)

    connection.close()
    return result

def check_request(request: Request):
    client_host = request.client.host
    if f"{client_host}" != "127.0.0.1":
        raise HTTPException(status_code=401)

@app.get("/contacts/{contact_id}")
def get_contacts_by_id(request: Request, contact_id: int):
    check_request(request)
    
    contact = get_contact(contact_id=contact_id)
    if not contact:
        raise HTTPException(status_code=404)

    return JSONResponse(
        status_code=200,
        content=contact
    )

@app.get("/contacts")
def get_contacts(request: Request):
    check_request(request)

    contacts = get_contact()

    if not contacts:
        return Response(status_code=204)

    return JSONResponse(
        status_code=200,
        content=contacts
    )

@app.post("/contacts")
def post_contact(
    request: Request, 
    title: str = Body(..., min_length=3, max_length=50),
    description: str = Body(..., min_length=1, max_length=255)
):
    print(title, description)
    check_request(request)

    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS contact (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            was_viewed BOOLEAN DEFAULT 0
        )
    """)
    connection.commit()
    
    cursor.execute("""
        INSERT INTO contact (title, description)
        VALUES (?, ?)
    """, (title, description))
    connection.commit()
    connection.close()

    return Response(status_code=201)

@app.put("/contacts/{contact_id}/viewed")
def viewed_contact(request: Request, contact_id: int):
    check_request(request)

    contact = get_contact(contact_id=contact_id)
    if not contact:
        raise HTTPException(status_code=404)

    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE contact
        SET was_viewed = 1
        WHERE id = ?;
    """, (contact_id,))
    connection.commit()
    connection.close()

    return Response(status_code=200)