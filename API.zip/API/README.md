![](print.gif)

> [!TIP]
> Crie um ambiente virtual no python para evitar contra-tempos

- Instalar dependencias com o comando:
```bash
python -m pip install -r requirements.txt
```
- Iniciar aplicacao com:
```bash
uvicorn main:app --port 8000
```

> [!NOTE]  
> Acesse a documentação em 127.0.0.1:8000/docs