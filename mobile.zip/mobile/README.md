<img src="image.png" alt="drawing" width="200"/>
<img src="image2.png" alt="drawing" width="200"/>

- Instalar dependencias com o comando:
```bash
flutter pub get
```
- Iniciar aplicacao com:
```bash
flutter run
```