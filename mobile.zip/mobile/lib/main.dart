import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const MainApp());
}

class Contact {
  final int id;
  final String title;
  final String description;
  final String createdAt;
  final bool wasViewed;

  Contact({
    required this.id,
    required this.title,
    required this.description,
    required this.createdAt,
    required this.wasViewed,
  });

  factory Contact.fromJson(Map<String, dynamic> json) {
    return Contact(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      createdAt: json['created_at'],
      wasViewed: json['was_viewed'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'created_at': createdAt,
      'was_viewed': wasViewed,
    };
  }
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'riodopeixeproject',
      home: HomePage(),
      debugShowCheckedModeBanner: false
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Contact> contacts = [];

  @override
  void initState() {
    super.initState();
    fetchContacts();
  }

  Future<void> fetchContacts() async {
    try {
      final response = await http.get(Uri.parse('http://10.0.2.2:8000/contacts'));
      if (response.statusCode != 200) {
        return;
      }

      setState(() {
        contacts = json.decode(response.body);
      });
    } catch(e) {
      print('Error: $e');
      setState(() {
        contacts = [
          Contact.fromJson({
            'id': 1,
            'title': 'O Rio do Peixe é a minha paixão!',
            'description': 'Eu adoro o Rio do Peixe porque é um lugar que sempre me traz paz e conexão com a natureza',
            'created_at': '2024-12-10',
            'was_viewed': false
          }),
          Contact.fromJson({
            'id': 2,
            'title': 'O Rio do Peixe é um paraíso escondido',
            'description': 'O Rio do Peixe é especial para mim porque representa um refúgio para aqueles que buscam beleza e '
                'tranquilidade. O som da água correndo e as paisagens deslumbrantes são inesquecíveis.',
            'created_at': '2024-12-13',
            'was_viewed': true
          })
        ];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'Preserve o Rio do Peixe',
          style: TextStyle(
            fontFamily: 'Segoe UI',
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 24
          )
        )
      ),
      body: contacts.isEmpty
        ? const Center(child: CircularProgressIndicator())
        : ListView.builder(
          itemCount: contacts.length,
          itemBuilder: (context, index) {
            final contact = contacts[index];
            return ListTile(
              title: Text(contact.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ContactDetailsScreen(contact: contact)
                  )
                );
              }
            );
          },
        )
    );
  }
}

class ContactDetailsScreen extends StatelessWidget {
  final Contact contact;

  const ContactDetailsScreen({Key? key, required this.contact}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        )
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              contact.title,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)
            ),
            const SizedBox(height: 16),
            Text(
              contact.description ?? 'Sem descrição',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
            Text(
              'Relatado em: ${contact.createdAt}',
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            )
          ],
        )
      )
    );
  }
}